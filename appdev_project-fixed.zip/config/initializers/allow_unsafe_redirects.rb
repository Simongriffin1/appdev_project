Rails.application.config.action_controller.raise_on_open_redirects = false
