require "rails_helper"

describe "This project" do
  it "is not graded" do
    expect(1).to eq(1)
  end
end
