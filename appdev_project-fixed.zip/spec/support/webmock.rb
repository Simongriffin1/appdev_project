# Allow any web request
WebMock.allow_net_connect!
# Only allow localhost (may not work in codespaces)
# WebMock.disable_net_connect!(allow_localhost: true)
