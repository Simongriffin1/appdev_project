class JournalReplyMailbox < ApplicationMailbox
  # Inbound email flow:
  # 1) User replies to an emailed prompt (Reply-To contains a signed token)
  # 2) Action Mailbox receives the email
  # 3) We decode the token to find user/prompt
  # 4) We create:
  #    - a JournalEntry (source: "email")
  #    - an EmailMessage record (direction: "inbound")
  # 5) We run AI analysis and auto-tag topics
  def process
    to_addr = Array(mail.to).first.to_s
    token = extract_token(to_addr)
    payload = ReplyToken.decode(token) if token.present?

    # If we can't verify, silently drop (or you can log it)
    return if payload.blank?

    user = User.find_by(id: payload["u"])
    prompt = Prompt.find_by(id: payload["p"], user_id: user&.id)
    return if user.blank?

    body_text = extract_body_text

    journal_entry = user.journal_entries.create!(
      prompt: prompt,
      body: body_text,
      source: "email"
    )

    EmailMessage.create!(
      user: user,
      direction: "inbound",
      prompt: prompt,
      journal_entry: journal_entry,
      subject: mail.subject.to_s,
      body: body_text,
      from_address: Array(mail.from).first.to_s,
      to_address: to_addr,
      message_id: mail.message_id.to_s,
      sent_or_received_at: mail.date || Time.current
    )

    EntryAnalysisGenerator.new(journal_entry).generate!
  end

  private

  def extract_token(to_addr)
    # reply+<token>@domain
    local = to_addr.split("@").first.to_s
    return nil unless local.start_with?("reply+")
    local.delete_prefix("reply+")
  end

  def extract_body_text
    # Prefer text/plain, fall back to decoded body
    if mail.multipart?
      part = mail.parts.find { |p| p.content_type.to_s.start_with?("text/plain") }
      return part.decoded.to_s.strip if part
    end

    mail.decoded.to_s.strip
  end
end
