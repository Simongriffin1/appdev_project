class ApplicationMailbox < ActionMailbox::Base
  # Route inbound mail sent to reply+<token>@... to our journaling mailbox.
  routing(/reply\+.+@/i => :journal_reply)
end
