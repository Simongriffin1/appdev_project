class ReplyToken
  # Small signed token used to safely associate inbound emails with a user/prompt.
  #
  # We embed this token in the Reply-To address, e.g.:
  #   reply+<token>@example.com
  #
  # When an inbound email arrives, Action Mailbox parses the token, verifies it,
  # and we create a JournalEntry + EmailMessage.
  def self.verifier
    Rails.application.message_verifier(:drift_reply)
  end

  def self.encode(user_id:, prompt_id:)
    verifier.generate({ "u" => user_id, "p" => prompt_id })
  end

  def self.decode(token)
    verifier.verify(token)
  rescue ActiveSupport::MessageVerifier::InvalidSignature
    nil
  end
end
