class PromptsController < ApplicationController
  before_action :set_prompt, only: [:show, :send_email]

  def index
    @prompts = current_user.prompts.order(created_at: :desc)
  end

  def show
    @journal_entry = current_user.journal_entries.new(prompt: @prompt)
  end

  def generate
    prompt = PromptGenerator.new(current_user).generate!
    redirect_to prompt_path(prompt), notice: "New prompt generated."
  end

  def send_email
    PromptMailer.with(user: current_user, prompt: @prompt).prompt_email.deliver_later

    EmailMessage.create!(
      user: current_user,
      direction: "outbound",
      prompt: @prompt,
      subject: "Your Drift prompt",
      body: @prompt.body,
      sent_or_received_at: Time.current
    )

    redirect_to prompt_path(@prompt), notice: "Prompt emailed to #{current_user.email}."
  end

  private

  def set_prompt
    @prompt = current_user.prompts.find(params[:id])
  end
end
