class PromptMailer < ApplicationMailer
  # Sends a prompt to the user with a reply-to address that can be ingested by Action Mailbox.
  #
  # For demo:
  # - Outbound emails will show up in the Rails logs (unless you configure SMTP).
  # - Inbound replies can be demoed via /rails/conductor/action_mailbox/inbound_emails
  #   by setting the "To" field to the reply-to address generated below.
  def prompt_email
    @user = params.fetch(:user)
    @prompt = params.fetch(:prompt)

    token = ReplyToken.encode(user_id: @user.id, prompt_id: @prompt.id)
    inbound_domain = ENV.fetch("INBOUND_EMAIL_DOMAIN", "example.com")
    reply_to_address = "reply+#{token}@#{inbound_domain}"

    mail(
      to: @user.email,
      reply_to: reply_to_address,
      subject: "Your Drift prompt",
    )
  end
end
