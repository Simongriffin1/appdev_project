class UpdateEmailMessagesForInbound < ActiveRecord::Migration[8.0]
  def change
    # Allow outbound prompt emails (no journal_entry yet) and optional prompt linking.
    change_column_null :email_messages, :prompt_id, true
    change_column_null :email_messages, :journal_entry_id, true

    add_column :email_messages, :from_address, :string
    add_column :email_messages, :to_address, :string
    add_column :email_messages, :message_id, :string

    add_index :email_messages, :message_id
    add_index :email_messages, [:user_id, :sent_or_received_at]
  end
end
